// pages/mbti/form/form.js
const app = getApp()

Page({
  data: {
    step: 1,
    name: '氧友',          // V0.8 不再收集姓名，用默认称呼
    birthday: '',
    gender: '',
    avatar: '',
    faceMood: '',        // happy/calm/tired (趣味感知mock)
    faceText: '',        // 趣味感知结果文案
    faceDetecting: false,
    canSubmit: false
  },

  onAvatarTap() {
    // 趣味表情感知(非真人脸识别, 仅UI演示)
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({
          avatar: res.tempFiles[0].tempFilePath,
          faceDetecting: true,
          faceText: '氧氧正在观察你的今日状态...'
        }, () => {
          // mock: 1.5s 后给出趣味感知结果
          setTimeout(() => {
            const moods = ['happy', 'calm', 'tired']
            const mood = moods[Math.floor(Math.random() * moods.length)]
            const txt = {
              happy: '检测到：你的表情看起来很开心，元气满满 ☀️',
              calm: '检测到：你的表情看起来比较放松，很安稳 🌱',
              tired: '检测到：你看起来有点疲惫，记得好好休息 🛋️'
            }[mood]
            // 保存到全局,后续MBTI结果页可读取
            app.globalData.faceMood = { mood, confidence: 0.8 + Math.random() * 0.15 }
            this.setData({ faceDetecting: false, faceMood: mood, faceText: txt })
          }, 1500)
        })
      }
    })
  },

  onBirthday(e) { this.setData({ birthday: e.detail.value }, () => this.check()) },
  onGender(e) { this.setData({ gender: e.currentTarget.dataset.g }, () => this.check()) },

  // V0.8 不再需要姓名，只需生日+性别即可提交
  check() {
    const { birthday, gender } = this.data
    this.setData({ canSubmit: birthday && gender })
  },

  next() {
    if (!this.data.canSubmit) {
      wx.showToast({ title: '请完善生日和性别哦', icon: 'none' })
      return
    }
    app.globalData.user = {
      name: this.data.name || '氧友',
      birthday: this.data.birthday,
      gender: this.data.gender,
      avatar: this.data.avatar,
      personality: '',
      hasTestedMBTI: false
    }
    app.globalData.faceMood = app.globalData.faceMood || { mood: this.data.faceMood || 'calm', confidence: 0.85 }
    wx.navigateTo({ url: '/pages/mbti/loading/loading' })
  }
})
