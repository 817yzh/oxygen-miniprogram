/**
 * pages/home/home.js
 * V2.0 · 极简治愈首页逻辑
 *
 * 保留: 问候语 / 氧气数据加载 / 陪伴天数 / 成长信息
 * 新增: IP点击互动(震动+Q弹+治愈气泡) / 球体点击上滑四维面板 / 跳转呼吸引导页
 * 移除: 视频播放 / 场景卡片 / 今日建议卡 / 行动卡(均收进其他页面)
 */

const app = getApp()
const { GREETING_LIST } = require('../../mock/data.js')
const { getOxygenMap } = require('../../mock/oxygen-map-db.js')
const { getComfortWord, detectSceneByScore } = require('../../mock/comfort-words-db.js')

Page({
  data: {
    // 问候
    greetMain: '晚上好',
    userName: '涵涵',
    companionDay: 1,
    // 氧气数据
    oxygenMetrics: [],    // 四维指标 [{key,label,icon,value}]
    oxygenScore: 70,      // 综合指数(四维均值)
    oxygenHint: '',       // 状态提示语
    // 四维雷达图数据（radar-chart组件需要的格式）
    radarIndexes: {},     // {emotion:70, oxygen:65, vigor:86, recover:85}
    radarDimensions: [],  // [{key, name}]
    // V2.0 交互状态
    showDimBubbles: false,       // 维度气泡是否弹出
    showComfortBubble: false,   // 治愈气泡是否显示
    comfortWord: '',            // 当前治愈文案
    ipTapActive: false,         // IP是否在Q弹动画中
    // V3.0 今日充氧手账抽屉
    drawerOpen: false,          // 手账抽屉是否打开
    todayRecorded: false,       // 今日是否已记录
    moodOptions: [              // 心情胶囊选项
      { key: 'breeze', icon: '☁️', label: '宁静微风' },
      { key: 'full',   icon: '⚡', label: '能量满格' },
      { key: 'unwind', icon: '🌙', label: '想要放空' }
    ],
    moodPick: '',               // 已选心情
    noteText: ''                // 手账文字
  },

  onLoad() {
    this.setGreeting()
    this.loadOxygenData()
  },

  onShow() {
    this.refresh()
  },

  // ========== 问候语（按时段） ==========
  setGreeting() {
    const h = new Date().getHours()
    let period = 'relax'
    let greetMain = '晚上好'
    if (h >= 6 && h < 11) { period = 'morning'; greetMain = '早上好' }
    else if (h >= 11 && h < 18) { period = 'energy'; greetMain = '午安' }
    else { period = 'relax'; greetMain = h >= 18 && h < 22 ? '晚上好' : '夜深了' }
    this.setData({ greetMain })
  },

  // ========== 刷新数据（页面显示时调用） ==========
  refresh() {
    const user = app.globalData.user
    this.setData({
      userName: (user && user.name) || '涵涵',
      companionDay: this.getCompanionDay(),
      todayRecorded: app.hasTodayRecord ? app.hasTodayRecord() : !!app.globalData.todayRecord
    })
    this.loadOxygenData()
  },

  // 陪伴天数（来自 companion.checkinDays）
  getCompanionDay() {
    const c = (app.globalData && app.globalData.companion) || {}
    return c.checkinDays || 1
  },

  // ========== 加载氧气数据（四维+综合指数） ==========
  loadOxygenData() {
    // 场景倾向：如果今日有打卡记录，用打卡场景影响数据
    const todayRecord = app.globalData.todayRecord
    const scene = (todayRecord && todayRecord.state) || ''
    const map = getOxygenMap(scene)
    // 维度文案口语化映射（去掉体检报告味）
    const labelMap = {
      '情绪能量': '心情晴雨',
      '身体含氧感': '身体轻松度',
      '活力指数': '续航力',
      '恢复状态': '夜间恢复力'
    }
    const spokenMetrics = map.metrics.map(m => ({
      ...m,
      label: labelMap[m.label] || m.label
    }))
    this.setData({
      oxygenMetrics: spokenMetrics,
      oxygenHint: map.hint,
      oxygenScore: this.calcOxygenScore(map.metrics),
      // 转换为radar-chart组件需要的格式
      radarIndexes: this.buildRadarIndexes(map.metrics),
      radarDimensions: this.buildRadarDimensions(map.metrics)
    })
  },

  // 计算氧气综合指数（四维均值）
  calcOxygenScore(metrics) {
    const arr = Array.isArray(metrics) ? metrics : []
    if (arr.length === 0) return 70
    let sum = 0
    arr.forEach(m => { sum += Number(m.value) || 0 })
    return Math.round(sum / arr.length)
  },

  // 把四维指标转为雷达图的indexes格式 {key: value}
  buildRadarIndexes(metrics) {
    const obj = {}
    const arr = Array.isArray(metrics) ? metrics : []
    arr.forEach(m => { obj[m.key] = Number(m.value) || 0 })
    return obj
  },

  // 把四维指标转为雷达图的dimensions格式 [{key, name}]
  buildRadarDimensions(metrics) {
    const arr = Array.isArray(metrics) ? metrics : []
    return arr.map(m => ({ key: m.key, name: m.label }))
  },

  // ========== V2.0 交互①：点击IP ==========
  // V3.0 改为：点击IP → 打开「今日充氧手账」抽屉（轻量打卡入口）
  onIpTap(e) {
    // 阻止事件冒泡到球体（避免同时打开四维面板）
    if (e && e.stopPropagation) e.stopPropagation()

    // 1. 轻微震动反馈
    wx.vibrateShort({ type: 'light' })

    // 2. Q弹动画
    this.setData({ ipTapActive: true })
    setTimeout(() => {
      this.setData({ ipTapActive: false })
    }, 500)

    // 3. 已记录 → 弹治愈气泡陪伴；未记录 → 打开手账抽屉
    if (this.data.todayRecorded) {
      const scene = detectSceneByScore(this.data.oxygenScore)
      const word = getComfortWord(scene)
      this.setData({ comfortWord: word, showComfortBubble: true })
      clearTimeout(this._bubbleTimer)
      this._bubbleTimer = setTimeout(() => {
        this.setData({ showComfortBubble: false })
      }, 3000)
    } else {
      this.openDrawer()
    }
  },

  // ========== V3.0 今日充氧手账抽屉 ==========
  openDrawer() {
    this.setData({ drawerOpen: true })
  },
  closeDrawer() {
    this.setData({ drawerOpen: false })
  },
  // 阻止遮罩层滚动穿透
  noop() {},

  // 选择心情胶囊
  onPickMood(e) {
    const key = e.currentTarget.dataset.key
    wx.vibrateShort({ type: 'light' })
    this.setData({ moodPick: key })
  },

  // 手账输入
  onNoteInput(e) {
    this.setData({ noteText: e.detail.value })
  },

  // 确认完成今日充氧
  confirmCheckin() {
    if (!this.data.moodPick) {
      wx.showToast({ title: '先选一个此刻的心情吧', icon: 'none' })
      return
    }
    // 记录（轻量打卡）
    app.addQuickRecord(this.data.moodPick, this.data.noteText)

    // 反馈：抽屉收回 + IP开心 + 天数跳动 +1
    this.setData({ drawerOpen: false, moodPick: '', noteText: '' })
    wx.vibrateShort({ type: 'light' })

    // IP 开心庆祝动效（Q弹）
    this.setData({ ipTapActive: true })
    setTimeout(() => this.setData({ ipTapActive: false }), 600)

    // 刷新数据（天数 +1、今日已记录点亮）
    setTimeout(() => this.refresh(), 350)

    wx.showToast({ title: '今日充氧已完成，明天见 💚', icon: 'none' })
  },

  // ========== V2.0 交互②：点击球体 → 弹出/收起维度气泡 ==========
  onBallTap() {
    const show = !this.data.showDimBubbles
    this.setData({ showDimBubbles: show })
    // 弹出时轻微震动反馈
    if (show) {
      wx.vibrateShort({ type: 'light' })
    }
  },

  // ========== V2.0 交互③：点击吸氧按钮 → 跳转呼吸引导页 ==========
  startOxygenTherapy() {
    wx.navigateTo({
      url: '/pages/breathing/breathing',
      fail: () => {
        // 如果页面未注册，降级提示
        wx.showToast({ title: '呼吸引导即将上线 🫁', icon: 'none' })
      }
    })
  },

  // ========== 导航 ==========
  goReport() {
    this.setData({ showDimBubbles: false })
    wx.navigateTo({ url: '/pages/report/report' })
  },

  goCheckin() { wx.navigateTo({ url: '/pages/checkin/checkin' }) },
  goGrowth() { wx.navigateTo({ url: '/pages/growth/growth' }) },
  goChat() { wx.navigateTo({ url: '/pages/chat/chat' }) },
  goProfile() { wx.switchTab({ url: '/pages/profile/profile' }) }
})
