// 小程序运行配置
// 品牌视频须使用已加入小程序合法域名的线上 HTTPS 地址；留空时首页不展示视频位。
module.exports = {
  introVideoUrl: ''
}
