/* mock-api.js 契约自测:25 条联调基准样本 + 边界降级 + 五字段契约 */
"use strict";
require("./web/js/mock-api.js"); // 挂到 globalThis.OxyAPI
const OxyAPI = globalThis.OxyAPI;

let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { pass++; console.log("PASS", name, detail || ""); }
  else { fail++; failures.push(name); console.log("FAIL", name, detail || ""); }
}

const FIVE_FIELDS = ["emotion", "confidence", "advice", "persona", "personaDesc"];
const EMOTION_SET = ["疲惫", "焦虑", "低落", "烦躁", "平静", "愉悦", "孤独", "恢复无力"];

function checkContract(name, r, scene) {
  const missing = FIVE_FIELDS.filter((f) => typeof r[f] !== (f === "confidence" ? "number" : "string") || (f !== "confidence" && !r[f]));
  check(name + " 五字段", missing.length === 0, missing.length ? "缺:" + missing.join(",") : "");
  check(name + " 情绪∈8类", EMOTION_SET.includes(r.emotion), r.emotion);
  check(name + " 置信度0.5-0.95两位小数", r.confidence >= 0.5 && r.confidence <= 0.95 && /^\d+(\.\d{1,2})?$/.test(String(r.confidence)), String(r.confidence));
  check(name + " persona句式", /^今日是.{2,8}的小狐狸$/.test(r.persona) && r.persona.length >= 6 && r.persona.length <= 15, r.persona);
  check(name + " 展示字段", typeof r.emoji === "string" && typeof r.color === "string" && r.emoji && /^#/.test(r.color), "");
  check(name + " scene透传", r.scene === (scene || null), String(r.scene));
  check(name + " source标注", ["sample", "keywords", "degrade"].includes(r.source), r.source);
}

(async () => {
  // ① 23 条查找表样本(P/B/S/G ×5 + E3/E4/E5)
  const jobs = OxyAPI.SAMPLES.map((s) =>
    OxyAPI.analyzeEmotion({ text: s.text, scene: s.scene }).then((r) => {
      check(s.id + " 期望情绪=" + s.expect, r.emotion === s.expect, `got=${r.emotion} conf=${r.confidence} src=${r.source}(${r.sampleId || "-"})`);
      check(s.id + " 命中样本层", r.source === "sample" && r.sampleId === s.id, r.source);
      checkContract(s.id, r, s.scene);
    })
  );

  // ② 边界降级:E1 空输入 / E2 乱码 / 纯空白 / 纯标点 → 平静 0.6 degrade
  const degradeCases = [
    ["E1 空输入", ""], ["E2 乱码", "abcd1234!@#$"], ["纯空白", "   \n\t "], ["纯标点", "!!!???。。。"],
  ];
  degradeCases.forEach(([name, text]) =>
    jobs.push(OxyAPI.analyzeEmotion({ text, scene: "plateau" }).then((r) => {
      check(name + " 降级平静0.6", r.emotion === "平静" && r.confidence === 0.6 && r.source === "degrade", `${r.emotion}/${r.confidence}/${r.source}`);
      checkContract(name, r, "plateau");
    }))
  );

  // ③ 与情绪无关的中文(无锚点)→ 平静 0.6 degrade
  jobs.push(OxyAPI.analyzeEmotion({ text: "今天中午吃了米饭和青菜", scene: null }).then((r) => {
    check("无关输入 降级平静0.6", r.emotion === "平静" && r.confidence === 0.6 && r.source === "degrade", `${r.emotion}/${r.confidence}/${r.source}`);
  }));

  // ④ 关键词引擎(非样本输入)
  const kwCases = [
    ["改写P1近似", "第一次来高海拔,一动就喘不上气,心跳好快,有点害怕", "焦虑", "sample"],   // 模糊命中样本
    ["通用疲惫", "今天加班到深夜,感觉特别累,浑身没劲", "疲惫", "keywords"],
    ["通用烦躁", "楼下装修吵死了,真烦", "烦躁", "keywords"],
    ["通用孤独", "过节了还是一个人,有点想家", "孤独", "keywords"],
    ["tie-break brain场景", "有点累也有点烦", "烦躁", "keywords"],
    ["tie-break 无场景", "有点累也有点烦", "疲惫", "keywords"],
  ];
  kwCases.forEach(([name, text, expect, src]) =>
    jobs.push(OxyAPI.analyzeEmotion({ text, scene: name.includes("brain") ? "brain" : null }).then((r) => {
      check(name + " →" + expect, r.emotion === expect && r.source === src, `got=${r.emotion}/${r.source} conf=${r.confidence}`);
    }))
  );

  await Promise.all(jobs);

  // ⑤ 置信度区分度:跨判定层(样本精确/样本模糊/关键词/降级)不应恒定
  const confInputs = [
    { text: OxyAPI.SAMPLES[0].text, scene: OxyAPI.SAMPLES[0].scene },          // 精确样本 → 0.9
    { text: "第一次来高海拔,一动就喘不上气,心跳好快,有点害怕", scene: "plateau" }, // 模糊样本 → 0.84
    { text: "今天加班到深夜,感觉特别累,浑身没劲", scene: null },                 // 关键词层
    { text: "", scene: null },                                                  // 降级 → 0.6
  ];
  const confs = await Promise.all(confInputs.map((i) => OxyAPI.analyzeEmotion(i).then((r) => r.confidence)));
  check("置信度不恒定(跨层)", new Set(confs).size >= 2, [...new Set(confs)].join("/"));

  console.log(`\n===== 结果: ${pass} PASS / ${fail} FAIL =====`);
  if (fail) { console.log("失败项:", failures.join(" | ")); process.exit(1); }
})();
