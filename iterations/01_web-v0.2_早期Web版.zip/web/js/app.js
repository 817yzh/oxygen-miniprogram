/* ============================================================
   app.js — 首版核心闭环可视化(纯前端,无后端依赖)
   页面:P1 首页 / P2 情绪检测 / P3 分析中 / P4 结果 / P5 推荐 / P7 我的·成长
   数据:localStorage 持久化(打卡记录、连续天数、氧氧经验)
   ============================================================ */

(function () {
  "use strict";

  var LS_KEY = "oxy_state_v1";

  /* ---------------- 状态 ---------------- */
  var state = loadState();
  var currentScene = null;   // 本次打卡的场景上下文
  var currentResult = null;  // 最近一次识别结果

  function loadState() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { /* 隐私模式等场景下降级为内存态 */ }
    return { history: [], xp: 0 };
  }
  function saveState() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) { /* 忽略 */ }
  }

  /* ---------------- 路由 ---------------- */
  var SCREENS = ["home", "checkin", "analyzing", "result", "recommend", "profile"];

  function nav(name) {
    SCREENS.forEach(function (s) {
      document.getElementById("screen-" + s).classList.toggle("active", s === name);
    });
    document.querySelectorAll(".tabbar .tab").forEach(function (t) {
      var target = t.getAttribute("data-nav");
      var isActive = target === name || (target === "checkin" && (name === "analyzing" || name === "result"));
      t.classList.toggle("active", isActive);
    });
    window.scrollTo(0, 0);
    if (name === "home") renderHome();
    if (name === "profile") renderProfile();
  }

  document.querySelectorAll("[data-nav]").forEach(function (el) {
    el.addEventListener("click", function () { nav(el.getAttribute("data-nav")); });
  });

  // 底部「打卡」Tab 进入时重置场景上下文并刷新检测页(场景卡片入口会自行设置场景)
  document.querySelector(".tabbar .tab-center").addEventListener("click", function () {
    currentScene = null;
    renderCheckin();
  });

  /* ---------------- 首页 ---------------- */
  function greetingText() {
    var h = new Date().getHours();
    if (h < 6) return "夜深啦";
    if (h < 11) return "早上好呀";
    if (h < 14) return "中午好呀";
    if (h < 18) return "下午好呀";
    return "晚上好呀";
  }

  function todayKey() {
    var d = new Date();
    return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
  }

  function renderHome() {
    document.getElementById("greeting").textContent = greetingText();

    // 今日状态卡
    var card = document.getElementById("today-card");
    var today = state.history.filter(function (r) { return r.dateKey === todayKey(); })[0];
    if (today) {
      card.innerHTML =
        '<div class="today-summary">' +
          '<div class="today-emoji">' + today.emoji + "</div>" +
          "<div>" +
            '<p class="t-title">' + today.persona + "</p>" +
            '<p class="t-sub">情绪参考标签:「' + today.emotion + "」 · 氧氧经验 +1</p>" +
          "</div>" +
        "</div>";
    } else {
      card.innerHTML =
        '<div class="today-empty">' +
          '<div class="empty-icon">🌤️</div>' +
          "<p>今天还没和氧氧打招呼呢<br>花 30 秒,说说现在的状态吧</p>" +
          '<button class="btn btn-primary" id="btn-quick-checkin">开始今日打卡</button>' +
        "</div>";
      document.getElementById("btn-quick-checkin").addEventListener("click", function () {
        currentScene = null;
        nav("checkin");
        renderCheckin();
      });
    }

    // 四场景入口
    var grid = document.getElementById("scene-grid");
    grid.innerHTML = "";
    Object.keys(OxyAPI.SCENES).forEach(function (key) {
      var s = OxyAPI.SCENES[key];
      var btn = document.createElement("button");
      btn.className = "scene-card";
      btn.innerHTML =
        '<div class="s-icon">' + s.icon + "</div>" +
        '<div class="s-name">' + s.name + "</div>" +
        '<div class="s-desc">' + s.hint.split(",")[0].split("。")[0] + "</div>";
      btn.addEventListener("click", function () {
        currentScene = key;
        nav("checkin");
        renderCheckin();
      });
      grid.appendChild(btn);
    });

    // 近 7 天历史
    renderHistory(document.getElementById("history-card"), 7);
  }

  function renderHistory(container, limit) {
    var list = state.history.slice(0, limit || 30);
    if (!list.length) {
      container.innerHTML = '<p class="history-empty">还没有记录,完成第一次打卡后这里会开出小花。</p>';
      return;
    }
    container.innerHTML = list.map(function (r) {
      return (
        '<div class="history-row">' +
          '<span class="h-date">' + r.dateLabel + "</span>" +
          '<span class="h-emoji">' + r.emoji + "</span>" +
          "<span>" +
            '<span class="h-tag">' + r.emotion + "</span><br>" +
            '<span class="h-persona">' + r.persona + "</span>" +
          "</span>" +
        "</div>"
      );
    }).join("");
  }

  /* ---------------- 检测页 ---------------- */
  var EXAMPLES = [
    "今天事情好多,有点焦虑",
    "练完腿好酸,感觉没恢复过来",
    "一个人在家,有点想孩子",
    "挺平静的,就是有点困"
  ];

  function renderCheckin() {
    var ctx = document.getElementById("scene-context");
    if (currentScene && OxyAPI.SCENES[currentScene]) {
      var s = OxyAPI.SCENES[currentScene];
      ctx.hidden = false;
      ctx.textContent = s.icon + " " + s.name + " · " + s.hint;
    } else {
      ctx.hidden = true;
    }

    var chips = document.getElementById("example-chips");
    chips.innerHTML = "";
    EXAMPLES.forEach(function (t) {
      var c = document.createElement("button");
      c.className = "chip";
      c.textContent = t;
      c.addEventListener("click", function () {
        var input = document.getElementById("mood-input");
        input.value = t;
        updateCount();
        input.focus();
      });
      chips.appendChild(c);
    });
    updateCount();
  }

  function updateCount() {
    var len = document.getElementById("mood-input").value.length;
    document.getElementById("char-count").textContent = len + "/200";
  }
  document.getElementById("mood-input").addEventListener("input", updateCount);

  // 通道切换(拍照为 UI 预留)
  document.querySelectorAll(".channel-tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll(".channel-tab").forEach(function (t) { t.classList.remove("active"); });
      tab.classList.add("active");
      var ch = tab.getAttribute("data-channel");
      document.getElementById("panel-text").classList.toggle("active", ch === "text");
      document.getElementById("panel-photo").classList.toggle("active", ch === "photo");
    });
  });

  /* ---------------- 分析中 + 结果 ---------------- */
  var ANALYZING_TEXTS = [
    "氧氧正在感受你的状态…",
    "竖起小耳朵,认真听你说…",
    "正在为你整理今日的情绪小卡片…"
  ];

  document.getElementById("btn-analyze").addEventListener("click", function () {
    var text = document.getElementById("mood-input").value.trim();
    if (!text) {
      document.getElementById("mood-input").focus();
      document.getElementById("mood-input").placeholder = "先写一两句,氧氧才能更懂你哦";
      return;
    }

    nav("analyzing");
    var i = 0;
    var textEl = document.getElementById("analyzing-text");
    textEl.textContent = ANALYZING_TEXTS[0];
    var timer = setInterval(function () {
      i = (i + 1) % ANALYZING_TEXTS.length;
      textEl.textContent = ANALYZING_TEXTS[i];
    }, 1100);

    // 调用 mock API(接口契约:{ emotion, confidence, advice, ... })
    OxyAPI.analyzeEmotion({ text: text, scene: currentScene }).then(function (res) {
      clearInterval(timer);
      currentResult = res;

      // 沉淀打卡记录 + 氧氧经验
      var d = new Date();
      state.history.unshift({
        dateKey: todayKey(),
        dateLabel: (d.getMonth() + 1) + "月" + d.getDate() + "日",
        emotion: res.emotion,
        persona: res.persona,
        emoji: res.emoji
      });
      state.xp += 1;
      saveState();

      renderResult(res);
      nav("result");
    });
  });

  function renderResult(res) {
    document.getElementById("result-emotion").textContent = "情绪参考:「" + res.emotion + "」";
    document.getElementById("result-persona").textContent = res.persona;
    document.getElementById("result-desc").textContent = res.personaDesc;
    document.getElementById("result-advice").textContent = res.advice;
    // 氧环情绪光:随当日情绪变化(合规:不展示置信度分数,仅作视觉氛围)
    document.querySelectorAll("[data-oxy-ring]").forEach(function (ring) {
      ring.style.background = "conic-gradient(" + res.color + ", #FFA863, " + res.color + ")";
    });
  }

  document.getElementById("btn-recheck").addEventListener("click", function () {
    document.getElementById("mood-input").value = "";
    nav("checkin");
    renderCheckin();
  });

  /* ---------------- 推荐页 ---------------- */
  document.getElementById("btn-goto-recommend").addEventListener("click", function () {
    renderRecommend();
    nav("recommend");
  });

  function renderRecommend() {
    var res = currentResult;
    var ctx = document.getElementById("recommend-context");
    var sceneObj = res && res.scene ? OxyAPI.SCENES[res.scene] : null;
    ctx.innerHTML = sceneObj
      ? "结合你的「<b>" + sceneObj.name + "</b>」场景与情绪参考「<b>" + (res ? res.emotion : "--") + "</b>」,氧氧为你准备了以下参考:"
      : "结合你的情绪参考「<b>" + (res ? res.emotion : "--") + "</b>」,氧氧为你准备了以下参考:";

    var list = document.getElementById("product-list");
    var products = OxyAPI.PRODUCTS.filter(function (p) {
      return !res || !res.scene || p.scenes.indexOf(res.scene) !== -1;
    });
    if (!products.length) products = OxyAPI.PRODUCTS;

    list.innerHTML = "";
    products.forEach(function (p) {
      var card = document.createElement("div");
      card.className = "card product-card";
      card.innerHTML =
        '<div class="product-img">' + p.icon + "</div>" +
        '<div class="product-info">' +
          '<span class="product-tag">' + p.tag + "</span>" +
          '<p class="product-name">' + p.name + "</p>" +
          '<p class="product-reason">' + p.reason + "</p>" +
          '<span class="product-link">了解详情 ›(占位)</span>' +
        "</div>";
      list.appendChild(card);
    });
  }

  /* ---------------- 我的/成长页 ---------------- */
  var LEVELS = [
    { name: "L1 · 初遇幼狐", min: 0,  sub: "我们才刚刚认识,多来陪我打卡吧。" },
    { name: "L2 · 同行暖狐", min: 5,  sub: "已经开始熟悉彼此啦,继续保持。" },
    { name: "L3 · 守护灵狐", min: 15, sub: "氧氧长出了更亮的尾巴,一直在。" },
    { name: "L4 · 共生光狐", min: 30, sub: "我们是彼此陪伴的老朋友了。" }
  ];
  var LEVEL_CAPS = [5, 15, 30, 50]; // 每级所需经验(末级封顶展示用)

  function currentLevel() {
    var lv = 0;
    for (var i = 0; i < LEVELS.length; i++) {
      if (state.xp >= LEVELS[i].min) lv = i;
    }
    return lv;
  }

  function calcStreak() {
    if (!state.history.length) return 0;
    var keys = {};
    state.history.forEach(function (r) { keys[r.dateKey] = true; });
    var streak = 0;
    var d = new Date();
    // 今天没打卡时,从昨天开始往回数也不断 streak 的语义简化:必须含今天
    while (keys[d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()]) {
      streak++;
      d.setDate(d.getDate() - 1);
    }
    return streak;
  }

  function renderProfile() {
    var lv = currentLevel();
    document.getElementById("growth-level").textContent = LEVELS[lv].name;
    document.getElementById("growth-sub").textContent = LEVELS[lv].sub;

    // 进度条:当前等级内进度
    var base = LEVELS[lv].min;
    var cap = LEVEL_CAPS[lv];
    var pct = Math.min(((state.xp - base) / (cap - base)) * 100, 100);
    document.getElementById("level-fill").style.width = Math.max(pct, 6) + "%";
    for (var i = 2; i <= 4; i++) {
      document.getElementById("mark-l" + i).classList.toggle("active", lv >= i - 1);
    }

    document.getElementById("stat-streak").textContent = calcStreak();
    document.getElementById("stat-total").textContent = state.history.length;
    renderHistory(document.getElementById("profile-history"), 30);
  }

  /* ---------------- 启动 ---------------- */
  renderHome();
})();
