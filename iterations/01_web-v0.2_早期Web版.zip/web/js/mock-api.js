/* ============================================================
   mock-api.js — 情绪识别 Mock 层(v0.2,对齐联调输入基准)
   ------------------------------------------------------------
   接口契约(与拍板的五字段契约 / 氧氧 system prompt 模板 v1.0 一致):
     输入:  { text: string, scene?: "plateau"|"brain"|"sport"|"silver"|null }
     输出:  {
       emotion:    string,   // 8 类基础情绪之一(疲惫/焦虑/低落/烦躁/平静/愉悦/孤独/恢复无力)
       confidence: number,   // 置信度 0~1 两位小数(仅数据字段,结果页不展示分数)
       advice:     string,   // 调节建议文本(合规口径:参考/建议/提示)
       persona:    string,   // 趣味画像,「今日是____的小狐狸」句式
       personaDesc:string,   // 趣味解读文本(氧氧视角,温暖不评判)
       emoji:      string,   // 展示用占位表情(前端展示字段)
       color:      string,   // 氧环情绪光语义色(前端展示字段)
       scene:      string|null,
       source:     "sample"|"keywords"|"degrade",  // 命中来源(联调调试字段)
       sampleId:   string|undefined                 // source=sample 时的用例编号
     }

   判定分三层(与联调输入基准严格对齐):
     ① 边界降级:空输入 / 乱码(无中文字符)→ 平静 0.6
     ② 样本基准:25 条《API实测用例输入集_四场景话术样本.md》
        (归一化精确匹配 conf=0.90,相似度≥0.82 模糊匹配 conf=0.84)
     ③ 关键词引擎:8 类锚点(模板 v1.0) + 样本衍生词,场景亲和 tie-break;
        无命中(与情绪无关)→ 平静 0.6

   接入真实 API 时,仅需把 analyzeEmotion 内部实现替换为
   fetch 调用并保持返回字段不变,前端其他模块无需改动。
   基准来源:共享工作区 API实测用例输入集_四场景话术样本.md(测试官 ③-A)
   ============================================================ */

(function (global) {
  "use strict";

  /* ---------------- 8 类基础情绪库 ----------------
     关键词 = 氧氧模板 v1.0「8 类锚点」+ 25 条样本衍生词;
     文案口径与模板 v1.0 语气示例一致(参考/建议/提示,不评判) */
  var EMOTIONS = [
    {
      key: "tired",
      emotion: "疲惫",
      keywords: ["累", "疲惫", "困", "没劲", "无力", "倦", "扛不住", "精疲力尽", "躺平", "不想动",
                 "掏空", "麻了", "酸胀", "僵", "抬不起来", "拿不稳"],
      persona: "今日是只想躺平的小狐狸",
      personaDesc: "身体和脑袋都在轻声说「想休息」。这不是偷懒,是它在提醒你:电量需要回充啦。",
      emoji: "😮‍💨",
      color: "#8FA8C9",
      advice: "建议今晚提前半小时放下手机,做 3 轮缓慢的腹式呼吸(吸气 4 拍、呼气 6 拍);白天可以给自己安排一段 10 分钟的「什么都不做」时间,小口补充温水。"
    },
    {
      key: "anxious",
      emotion: "焦虑",
      keywords: ["焦虑", "紧张", "担心", "慌", "压力", "不安", "害怕", "心跳", "睡不着", "失眠",
                 "高原反应", "高反", "头晕", "心慌", "有点紧", "晕"],
      persona: "今日是耳朵竖得高高的小狐狸",
      personaDesc: "好像有一点紧绷,像高原上的风一阵阵地吹。放轻松,氧氧陪着你,慢慢来。",
      emoji: "😟",
      color: "#A58BD4",
      advice: "提示:可以试试「4-7-8」呼吸法(吸气 4 秒、屏息 7 秒、呼气 8 秒),重复 3-4 轮;把担心的事写下来拆成小步骤,一次只做一件。若身体不适感持续,请及时休息并遵医嘱。"
    },
    {
      key: "low",
      emotion: "低落",
      keywords: ["难过", "低落", "伤心", "沮丧", "郁闷", "不开心", "emo", "丧", "哭", "委屈",
                 "没意思", "不想说话", "没用", "空落落", "提不起"],
      persona: "今日是尾巴耷拉着的小狐狸",
      personaDesc: "心里好像下了一场小雨。没关系,雨会停的,氧氧的尾巴借你靠一会儿。",
      emoji: "😔",
      color: "#7E9BB5",
      advice: "建议给自己一个微小的奖励:一杯热饮、一段喜欢的音乐,或出门晒 10 分钟太阳。也可以把心情写给信任的人看看。情绪参考提示:允许自己慢慢来。"
    },
    {
      key: "irritable",
      emotion: "烦躁",
      keywords: ["烦", "躁", "火大", "生气", "气死", "讨厌", "吵", "不耐烦", "爆炸", "想吐", "怼"],
      persona: "今日是炸毛的小狐狸",
      personaDesc: "毛毛都竖起来了,看什么都想「哼」一声。是脑袋里的小松鼠跑太快啦。",
      emoji: "😤",
      color: "#A58BD4",
      advice: "提示:先离开让你烦躁的环境 5 分钟,用冷水洗把脸;做几组肩颈拉伸,再配合缓慢的深呼吸。参考做法:把「必须做完」换成「先做 10 分钟」。"
    },
    {
      key: "calm",
      emotion: "平静",
      keywords: ["平静", "还好", "一般", "稳定", "放松", "舒服", "安宁", "可以", "不错"],
      persona: "今日是眯眼晒太阳的小狐狸",
      personaDesc: "像湖面一样稳稳的,是很棒的状态。保持这份松弛感,今天也很可爱。",
      emoji: "😌",
      color: "#5BB8A6",
      advice: "建议趁状态平稳,做一点轻量的拉伸或散步,为身体存一点「氧气余额」。参考提示:保持规律作息,平稳的日子也值得被记录。"
    },
    {
      key: "joy",
      emotion: "愉悦",
      keywords: ["开心", "高兴", "快乐", "棒", "太好了", "哈哈", "兴奋", "幸福", "满意", "顺利",
                 "好多了", "特别好", "通透", "在状态", "太美"],
      persona: "今日是尾巴摇成小风扇的小狐狸",
      personaDesc: "眼睛亮晶晶的!这样的好心情值得收藏,也值得分给身边的人一点点。",
      emoji: "😄",
      color: "#F5B84C",
      advice: "提示:把此刻的心情记录下来,低落的时候翻一翻会很管用。建议把这份能量用在一件你最喜欢的小事上,让快乐续航。"
    },
    {
      key: "lonely",
      emotion: "孤独",
      keywords: ["孤独", "孤单", "没人", "一个人", "寂寞", "想家", "想念", "子女", "陪伴", "发呆"],
      persona: "今日是望着远方的小狐狸",
      personaDesc: "心里有个角落想被听见。氧氧在这里,你想说多少,我就听多少。",
      emoji: "🥺",
      color: "#7E9BB5",
      advice: "建议主动发出一个小信号:给想念的人发一条消息,或约一次短短的通话。参考提示:每天固定的「说话时间」对心情很有帮助,哪怕只是和氧氧打卡。"
    },
    {
      key: "recover",
      emotion: "恢复无力",
      keywords: ["酸痛", "恢复", "运动", "跑完", "练完", "肌肉", "没恢复", "爬不动",
                 "半马", "拉伤", "翻身", "抖"],
      persona: "今日是运动后摊成饼的小狐狸",
      personaDesc: "努力过的身体正在悄悄修复,给它一点时间和耐心,恢复也是训练的一部分。",
      emoji: "🫠",
      color: "#8FA8C9",
      advice: "建议今天以轻度活动为主:慢走、拉伸、充足睡眠与蛋白质补充。提示:运动后 48 小时内的疲劳感多为正常恢复过程,若疼痛异常请遵医嘱。"
    }
  ];

  /* 边界降级结果(契约:空输入/乱码/与情绪无关 → 平静 0.6) */
  var DEFAULT_RESULT = {
    emotion: "平静",
    confidence: 0.6,
    persona: "今日是安静看世界的小狐狸",
    personaDesc: "文字不多,但氧氧都接收到啦。平平淡淡,也是值得被好好对待的一天。",
    emoji: "🦊",
    color: "#5BB8A6",
    advice: "建议多写一两句此刻的感受,氧氧能给出更贴近你的参考。今天也记得喝水、伸展、好好呼吸。"
  };

  /* ---------------- 联调输入基准:25 条样本 ----------------
     逐字取自《API实测用例输入集_四场景话术样本.md》(测试官 ③-A)。
     E1(空输入)/E2(乱码) 由降级层兜底,不在查找表内。
     导出供测评/联调复用:同一份基准可对照 mock 与真实 API。 */
  var SAMPLES = [
    { id: "P1", scene: "plateau", text: "第一次来高海拔，稍微一动就喘不上气，心跳得好快，有点害怕。", expect: "焦虑" },
    { id: "P2", scene: "plateau", text: "今晚住山上睡不着，头有点晕，是不是高反了，有点慌。", expect: "焦虑" },
    { id: "P3", scene: "plateau", text: "爬到 4500 米的时候突然一阵心慌气短，吓得我坐下来不敢动。", expect: "焦虑" },
    { id: "P4", scene: "plateau", text: "高原风景太美了，但一想到明天还要往上爬，心里就有点紧。", expect: "焦虑" },
    { id: "P5", scene: "plateau", text: "慢慢适应了，今天在山顶居然很平静，呼吸也稳了。", expect: "平静" },
    { id: "B1", scene: "brain",   text: "连续改了一天的方案，看到表格就想吐，谁说话我都想怼。", expect: "烦躁" },
    { id: "B2", scene: "brain",   text: "写不动了，脑子像糊了一层浆糊，效率极低，有点丧。", expect: "低落" },
    { id: "B3", scene: "brain",   text: "最近项目压力大，晚上躺下脑子里全是不安，根本睡不着。", expect: "焦虑" },
    { id: "B4", scene: "brain",   text: "盯着屏幕看了 10 小时，眼睛酸胀，肩膀也僵，整个人麻了。", expect: "疲惫" },
    { id: "B5", scene: "brain",   text: "关掉电脑那一刻，突然觉得什么都没意思，不想说话。", expect: "低落" },
    { id: "S1", scene: "sport",   text: "昨天跑了个半马，今早大腿完全抬不起来，下楼梯都是抖的。", expect: "恢复无力" },
    { id: "S2", scene: "sport",   text: "练完腿感觉整个人被掏空了，连筷子都拿不稳。", expect: "疲惫" },
    { id: "S3", scene: "sport",   text: "运动完虽然累，但心情特别好，整个人很通透。", expect: "愉悦" },
    { id: "S4", scene: "sport",   text: "爬完山第二天浑身酸痛，连翻身都疼，是不是拉伤了。", expect: "恢复无力" },
    { id: "S5", scene: "sport",   text: "休息了两天终于缓过来了，今天可以慢慢恢复训练。", expect: "平静" },
    { id: "G1", scene: "silver",  text: "孩子们都忙，今天又是一个人吃饭，屋里特别安静。", expect: "孤独" },
    { id: "G2", scene: "silver",  text: "最近老觉得自己没用了，啥也帮不上忙，心里空落落的。", expect: "低落" },
    { id: "G3", scene: "silver",  text: "想孙子了，可视频打过去孩子也不怎么说话，有点想哭。", expect: "孤独" },
    { id: "G4", scene: "silver",  text: "今天公园里遇到老朋友聊了一下午，心情好多了。", expect: "愉悦" },
    { id: "G5", scene: "silver",  text: "最近总是睡不好，半夜醒来一个人坐着发呆，日子越过越长。", expect: "孤独" },
    { id: "E3", scene: null,      text: "今天心情一般，还好。", expect: "平静" },
    { id: "E4", scene: null,      text: "又累又有点想哭，但好像也还行。", expect: "疲惫" },
    { id: "E5", scene: null,      text: "哈哈今天太顺利了，整个下午都在状态！", expect: "愉悦" }
  ];

  /* 场景亲和:tie-break 时优先(标签→场景 映射的首版占位) */
  var SCENE_AFFINITY = {
    plateau: ["anxious", "tired", "recover"],
    brain:   ["irritable", "low", "tired", "anxious"],
    sport:   ["recover", "tired"],
    silver:  ["lonely", "low"]
  };

  /* 场景修饰:用于推荐页上下文 */
  var SCENES = {
    plateau: { name: "高原出行", icon: "🏔️", hint: "高原场景常见紧张、气短感,注意循序渐进适应。" },
    brain:   { name: "脑疲劳",   icon: "🧠", hint: "长时间用脑后的烦躁、倦怠很常见,记得给大脑换换气。" },
    sport:   { name: "运动恢复", icon: "🏃", hint: "运动后疲惫与恢复无力是身体修复的信号。" },
    silver:  { name: "银发关怀", icon: "🌿", hint: "孤独感需要被温柔接住,规律的陪伴很重要。" }
  };

  /* 场景化产品推荐(产品原图暂缺,占位呈现;文案均为参考口径) */
  var PRODUCTS = [
    {
      id: "wa-x", name: "充氧宝 WA-X 便携款", icon: "🫧", tag: "场景参考",
      scenes: ["plateau", "brain"],
      reason: "高原出行或用脑过久时,可作为日常补氧的参考选择,帮助身体更舒适地适应节奏。"
    },
    {
      id: "wa-01", name: "充氧宝 WA-01 家用款", icon: "🏡", tag: "居家参考",
      scenes: ["silver", "brain", "plateau"],
      reason: "居家日常使用参考:配合规律作息,让每一次呼吸都更从容。"
    },
    {
      id: "f1", name: "共享租聘机 F1", icon: "🔄", tag: "出行参考",
      scenes: ["plateau", "sport"],
      reason: "旅行或运动后场景参考:按需使用更轻便,具体租用方式以线下点位说明为准。"
    },
    {
      id: "breath", name: "氧氧呼吸练习(内容)", icon: "🌬️", tag: "内容参考",
      scenes: ["plateau", "brain", "sport", "silver"],
      reason: "免费内容参考:跟着氧氧做 3 分钟呼吸练习,任何时候都可以开始。"
    }
  ];

  /* ---------------- 匹配工具 ---------------- */

  /* 归一化:小写 + 去除非中英数字符(标点/空白/全半角差异不敏感) */
  function normalize(s) {
    return String(s == null ? "" : s).toLowerCase().replace(/[^0-9a-z一-鿿]/g, "");
  }

  function hasCJK(s) {
    return /[一-鿿]/.test(s);
  }

  /* Dice 相似度(字符二元组),用于样本模糊匹配 */
  function similarity(a, b) {
    if (a === b) return 1;
    if (a.length < 2 || b.length < 2) return 0;
    var map = {};
    var i, k, inter = 0;
    for (i = 0; i < a.length - 1; i++) {
      k = a.substr(i, 2);
      map[k] = (map[k] || 0) + 1;
    }
    for (i = 0; i < b.length - 1; i++) {
      k = b.substr(i, 2);
      if (map[k]) { map[k]--; inter++; }
    }
    return (2 * inter) / (a.length - 1 + b.length - 1);
  }

  /* 样本查找:归一化精确命中,或相似度 ≥0.82 的最近样本 */
  function matchSample(ntext) {
    if (!ntext || ntext.length < 4) return null;
    var best = null, bestSim = 0, sim;
    for (var i = 0; i < SAMPLES.length; i++) {
      var s = SAMPLES[i];
      if (!s._norm) s._norm = normalize(s.text);
      if (ntext === s._norm) return { sample: s, exact: true };
      sim = similarity(ntext, s._norm);
      if (sim > bestSim) { bestSim = sim; best = s; }
    }
    return bestSim >= 0.82 ? { sample: best, exact: false } : null;
  }

  function byExpect(emotion) {
    for (var i = 0; i < EMOTIONS.length; i++) {
      if (EMOTIONS[i].emotion === emotion) return EMOTIONS[i];
    }
    return null;
  }

  function round2(n) { return Math.round(n * 100) / 100; }

  function buildResult(base, confidence, scene, source, sampleId) {
    return {
      emotion: base.emotion,
      confidence: round2(confidence),
      advice: base.advice,
      persona: base.persona,
      personaDesc: base.personaDesc,
      emoji: base.emoji,
      color: base.color,
      scene: scene || null,
      source: source,
      sampleId: sampleId
    };
  }

  /* 模拟网络时延,供「分析中」过渡页展示 */
  function defer(result) {
    return new Promise(function (resolve) {
      setTimeout(function () { resolve(result); }, 1600 + Math.random() * 800);
    });
  }

  /**
   * 情绪识别(前端 mock,与联调输入基准对齐)。
   * 换真实 API 时:把函数体替换为
   *   return fetch(API_URL, {...}).then(r => r.json()) // 保持返回字段一致
   * @param {{text:string, scene?:string}} input
   * @returns {Promise<object>} 契约见文件头注释
   */
  function analyzeEmotion(input) {
    var raw = input && input.text != null ? String(input.text) : "";
    var text = raw.trim();
    var scene = input && input.scene ? input.scene : null;

    /* ① 边界降级:空输入 / 乱码(无中文字符)→ 平静 0.6 */
    var ntext = normalize(text);
    if (!ntext || !hasCJK(text)) {
      return defer(buildResult(DEFAULT_RESULT, 0.6, scene, "degrade"));
    }

    /* ② 样本基准命中(25 条联调输入集)→ 期望情绪 */
    var sm = matchSample(ntext);
    if (sm) {
      var emo = byExpect(sm.sample.expect);
      if (emo) {
        return defer(buildResult(emo, sm.exact ? 0.9 : 0.84, scene, "sample", sm.sample.id));
      }
    }

    /* ③ 通用关键词引擎(非样本输入):命中数计分 + 场景亲和 tie-break */
    var maxHits = 0;
    var winners = [];
    for (var i = 0; i < EMOTIONS.length; i++) {
      var em = EMOTIONS[i];
      var hits = 0;
      for (var j = 0; j < em.keywords.length; j++) {
        if (text.indexOf(em.keywords[j]) !== -1) hits++;
      }
      if (hits > maxHits) { maxHits = hits; winners = [em]; }
      else if (hits === maxHits && hits > 0) { winners.push(em); }
    }

    /* 与情绪无关(无任何锚点命中)→ 平静 0.6 */
    if (maxHits === 0) {
      return defer(buildResult(DEFAULT_RESULT, 0.6, scene, "degrade"));
    }

    /* tie-break:场景亲和优先,否则保持 EMOTIONS 顺序先者 */
    var matched = winners[0];
    if (winners.length > 1 && scene && SCENE_AFFINITY[scene]) {
      var aff = SCENE_AFFINITY[scene];
      for (var a = 0; a < aff.length; a++) {
        for (var w = 0; w < winners.length; w++) {
          if (winners[w].key === aff[a]) { matched = winners[w]; a = aff.length; break; }
        }
      }
    }

    /* mock 置信度:命中锚点越多越高,封顶 0.95;仅作数据字段,页面不展示分数 */
    var confidence = Math.min(0.6 + maxHits * 0.12, 0.95);
    return defer(buildResult(matched, confidence, scene, "keywords"));
  }

  global.OxyAPI = {
    analyzeEmotion: analyzeEmotion,
    SCENES: SCENES,
    PRODUCTS: PRODUCTS,
    SAMPLES: SAMPLES   // 联调输入基准:供测评同学以同一 25 条对照 mock 与真实 API
  };
})(typeof window !== "undefined" ? window : globalThis);
